<template>
  <section style="background:#ffffff;">
      <section style="height:10px;"></section>
      <section style="background:#ffffff">
      <div style="text-align:center;">
        <img src="../../assets/icon/icon_user.png" style="width:2.5rem;height:2.5rem;border:1px solid #999"/>
            <div>小米</div>
      </div>
      <section style="text-align:center;">
          <div>手机号：13888888888</div>
          <div>微信号：XXXXXXXXXX</div>
      </section>
      <section style="height:5px;"></section>
      <div style="text-align:center;">
        <div>微信二维码</div>
        <div style="">
            <img src="../../assets/icon/icon_scan.png" style="width:5.0rem;height:5.0rem;border:1px solid #999"/>
        </div>
      </div>
    </section>
  </section>
</template>
<script>
export default {
  data() {
    return {
    };
  },
  mounted() {
  }
};
</script>

<style>

</style>

